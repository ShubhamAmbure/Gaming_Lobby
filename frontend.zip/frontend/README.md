## Quickstart

1. Install dependencies:

```powershell
cd frontend
npm install
```

2. Start the dev server:

```powershell
npm run dev
```

3. Open http://localhost:5173

## Key folders

- `frontend/src/` — application source
  - `components/` — reusable UI components
  - `pages/` — route pages
  - `context/` — global app context (`AppContext.jsx`)
  - `index.jsx` — app entry (wrapped with `AppProvider`)
- `frontend/public/` — static assets

## What I cleaned up

- Added `.gitignore` to avoid committing `node_modules` and build artifacts.
- Removed tracked build artifacts from the repo (committed separately).
